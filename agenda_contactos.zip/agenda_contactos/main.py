"""
main.py — Punto de entrada de la aplicación Agenda de Contactos.

Inicializa la conexión a MySQL, lanza el bucle del menú CLI
y garantiza el cierre limpio de la conexión al salir.
"""

import sys

from db.connection import Conexion
from cli.menu import run
from exceptions import ConexionBDError


def main():
    """
    Inicializa la conexión a la base de datos y arranca la interfaz CLI.

    Retorna:
        None

    Lanza:
        SystemExit: Con código 1 si no se puede conectar a la base de datos.
    """
    try:
        Conexion.obtener()
    except ConexionBDError as e:
        print(f"\n✗ No se pudo conectar a la base de datos:\n  {e}\n")
        print("  Comprueba que MySQL está en ejecución y que el fichero .env es correcto.")
        sys.exit(1)

    try:
        run()
    except KeyboardInterrupt:
        print("\n\n  Interrupción detectada. Saliendo...")
    finally:
        Conexion.cerrar()


if __name__ == "__main__":
    main()
