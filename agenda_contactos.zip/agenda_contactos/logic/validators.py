"""
logic/validators.py — Validación de campos del contacto.

Funciones puras sin efectos secundarios. Devuelven True si el valor es
válido o lanzan ValidationError con el código de error correspondiente.
"""

from __future__ import annotations
import re
from typing import Optional

from exceptions import ValidationError


# ── Expresiones regulares ────────────────────────────────────────────────────

_RE_NOMBRE = re.compile(r"^[A-Za-záéíóúüñÁÉÍÓÚÜÑàèìòùÀÈÌÒÙ\s\-']+$")
_RE_TELEFONO = re.compile(r"^[\d\s\+\(\)\-]+$")
_RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ── Funciones de validación individuales ────────────────────────────────────

def validar_nombre(nombre: str) -> bool:
    """
    Valida el campo nombre: no vacío, 2–100 caracteres, solo letras, espacios y guiones.

    Parámetros:
        nombre (str): Valor a validar.

    Retorna:
        bool: True si es válido.

    Lanza:
        ValidationError: ERR-001 si no cumple las reglas.
    """
    valor = (nombre or "").strip()
    if not valor or len(valor) < 2 or len(valor) > 100:
        raise ValidationError("ERR-001", "El nombre es obligatorio y debe tener entre 2 y 100 caracteres.")
    if not _RE_NOMBRE.match(valor):
        raise ValidationError("ERR-001", "El nombre solo puede contener letras, espacios y guiones.")
    return True


def validar_apellidos(apellidos: str) -> bool:
    """
    Valida los apellidos: opcional; si se proporciona debe tener 2–200 caracteres.

    Parámetros:
        apellidos (str): Valor a validar (puede ser None o vacío).

    Retorna:
        bool: True si es válido.

    Lanza:
        ValidationError: ERR-001 si el formato no es correcto.
    """
    valor = (apellidos or "").strip()
    if not valor:
        return True  # es opcional
    if len(valor) < 2 or len(valor) > 200:
        raise ValidationError("ERR-001", "Los apellidos deben tener entre 2 y 200 caracteres.")
    if not _RE_NOMBRE.match(valor):
        raise ValidationError("ERR-001", "Los apellidos solo pueden contener letras, espacios y guiones.")
    return True


def validar_telefono(tel: str, campo: str = "tel1") -> bool:
    """
    Valida un número de teléfono: dígitos, espacios, +, (, ), -. Longitud 7–20.

    Parámetros:
        tel   (str): Número de teléfono a validar.
        campo (str): Nombre del campo para personalizar el error.

    Retorna:
        bool: True si es válido.

    Lanza:
        ValidationError: ERR-004 si el formato es incorrecto.
    """
    valor = (tel or "").strip()
    if not valor:
        return True  # los teléfonos opcionales (tel2) pueden estar vacíos
    if len(valor) < 7 or len(valor) > 20:
        raise ValidationError("ERR-004", f"El formato del teléfono ({campo}) no es válido.")
    if not _RE_TELEFONO.match(valor):
        raise ValidationError("ERR-004", f"El formato del teléfono ({campo}) no es válido.")
    return True


def validar_email(email: str) -> bool:
    """
    Valida el email con formato básico usuario@dominio.tld.

    Parámetros:
        email (str): Dirección de correo a validar (puede ser None o vacío).

    Retorna:
        bool: True si es válido.

    Lanza:
        ValidationError: ERR-003 si el formato no es correcto.
    """
    valor = (email or "").strip()
    if not valor:
        return True  # el email es opcional
    if not _RE_EMAIL.match(valor):
        raise ValidationError("ERR-003", "El formato del email no es válido.")
    return True


def validar_notas(notas: str) -> bool:
    """
    Valida el campo notas: sin restricción de formato, máximo 5 000 caracteres.

    Parámetros:
        notas (str): Texto libre a validar.

    Retorna:
        bool: True si es válido.

    Lanza:
        ValidationError: Si supera el límite de caracteres.
    """
    valor = (notas or "").strip()
    if len(valor) > 5000:
        raise ValidationError("ERR-001", "Las notas no pueden superar los 5 000 caracteres.")
    return True


def validar_contacto(datos: dict) -> bool:
    """
    Valida el conjunto completo de datos de un contacto.

    Reglas globales:
    - nombre es obligatorio.
    - tel1 es obligatorio.

    Parámetros:
        datos (dict): Diccionario con los campos del contacto.

    Retorna:
        bool: True si todos los campos son válidos.

    Lanza:
        ValidationError: Con el código de error que corresponda al primer fallo.
    """
    validar_nombre(datos.get("nombre", ""))
    validar_apellidos(datos.get("apellidos", ""))

    tel1 = (datos.get("tel1") or "").strip()
    if not tel1:
        raise ValidationError("ERR-002", "Debe indicar al menos un teléfono (tel1).")
    validar_telefono(tel1, "tel1")
    validar_telefono(datos.get("tel2", ""), "tel2")
    validar_email(datos.get("email", ""))
    validar_notas(datos.get("notas", ""))

    return True
