"""
logic/services.py — Orquestación de los casos de uso de la agenda.

Es el único punto de contacto entre la capa CLI y la capa de repositorio.
La CLI nunca llama directamente a db/contact_repo.py.
"""

from __future__ import annotations
from typing import Optional

from logic import validators
from logic.models import Contacto
from db import contact_repo
from exceptions import (
    ContactoDuplicadoError,
    ContactoNoEncontradoError,
    ValidationError,
)


def crear_contacto(datos: dict, forzar: bool = False) -> Contacto:
    """
    Valida e inserta un nuevo contacto en la base de datos. (CU-01)

    Parámetros:
        datos  (dict): Campos del contacto (nombre, apellidos, tel1, tel2, email, notas).
        forzar (bool): Si True, omite la comprobación de duplicado.

    Retorna:
        Contacto: El contacto creado con su id asignado.

    Lanza:
        ValidationError:        Si algún campo no pasa la validación.
        ContactoDuplicadoError: Si ya existe un contacto con el mismo tel1 o email
                                y forzar=False.
        ConexionBDError:        Si falla la operación en base de datos.
    """
    validators.validar_contacto(datos)

    if not forzar:
        if contact_repo.existe_duplicado(
            tel1=datos.get("tel1"),
            email=datos.get("email") or None,
        ):
            raise ContactoDuplicadoError()

    id_nuevo = contact_repo.insertar(datos)
    fila = contact_repo.obtener_por_id(id_nuevo)
    return Contacto.desde_dict(fila)


def obtener_contacto(id_contacto: int) -> Contacto:
    """
    Recupera un contacto por su ID. (CU-02)

    Parámetros:
        id_contacto (int): Identificador único del contacto.

    Retorna:
        Contacto: El contacto encontrado.

    Lanza:
        ContactoNoEncontradoError: Si no existe ningún contacto activo con ese ID.
        ConexionBDError:           Si falla la operación en base de datos.
    """
    fila = contact_repo.obtener_por_id(id_contacto)
    if fila is None:
        raise ContactoNoEncontradoError(id_contacto)
    return Contacto.desde_dict(fila)


def listar_contactos(pagina: int = 1, tam: int = 20) -> tuple[list[Contacto], int]:
    """
    Devuelve una página de contactos activos y el total de registros. (CU-05)

    Parámetros:
        pagina (int): Número de página (1-based).
        tam    (int): Tamaño de página (por defecto 20).

    Retorna:
        tuple[list[Contacto], int]: Lista de contactos de la página y total de
                                    contactos activos.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    offset = (pagina - 1) * tam
    filas = contact_repo.listar(offset=offset, limit=tam)
    total = contact_repo.contar_total()
    return [Contacto.desde_dict(f) for f in filas], total


def buscar_contactos(termino: str) -> list[Contacto]:
    """
    Busca contactos por nombre, teléfono o email.

    Parámetros:
        termino (str): Cadena de búsqueda.

    Retorna:
        list[Contacto]: Lista de contactos que coinciden.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    termino = (termino or "").strip()
    filas = contact_repo.buscar(termino)
    return [Contacto.desde_dict(f) for f in filas]


def actualizar_contacto(id_contacto: int, cambios: dict) -> Contacto:
    """
    Valida y aplica cambios parciales a un contacto existente. (CU-04)

    Solo se actualizan los campos que aparezcan en `cambios` con valor no None.

    Parámetros:
        id_contacto (int):  ID del contacto a modificar.
        cambios     (dict): Diccionario con los campos y sus nuevos valores.

    Retorna:
        Contacto: El contacto actualizado.

    Lanza:
        ContactoNoEncontradoError: Si no existe ningún contacto activo con ese ID.
        ValidationError:           Si algún campo nuevo no pasa la validación.
        ConexionBDError:           Si falla la operación en base de datos.
    """
    # Verificar existencia
    fila_actual = contact_repo.obtener_por_id(id_contacto)
    if fila_actual is None:
        raise ContactoNoEncontradoError(id_contacto)

    # Validar solo los campos que cambian
    campos_a_actualizar = {k: v for k, v in cambios.items() if v is not None and v != ""}

    if "nombre" in campos_a_actualizar:
        validators.validar_nombre(campos_a_actualizar["nombre"])
    if "apellidos" in campos_a_actualizar:
        validators.validar_apellidos(campos_a_actualizar["apellidos"])
    if "tel1" in campos_a_actualizar:
        validators.validar_telefono(campos_a_actualizar["tel1"], "tel1")
    if "tel2" in campos_a_actualizar:
        validators.validar_telefono(campos_a_actualizar["tel2"], "tel2")
    if "email" in campos_a_actualizar:
        validators.validar_email(campos_a_actualizar["email"])
    if "notas" in campos_a_actualizar:
        validators.validar_notas(campos_a_actualizar["notas"])

    if campos_a_actualizar:
        contact_repo.actualizar(id_contacto, campos_a_actualizar)

    fila = contact_repo.obtener_por_id(id_contacto)
    return Contacto.desde_dict(fila)


def eliminar_contacto(id_contacto: int) -> bool:
    """
    Realiza un soft-delete del contacto. (CU-03)

    Parámetros:
        id_contacto (int): ID del contacto a eliminar.

    Retorna:
        bool: True si la eliminación fue exitosa.

    Lanza:
        ContactoNoEncontradoError: Si no existe ningún contacto activo con ese ID.
        ConexionBDError:           Si falla la operación en base de datos.
    """
    fila = contact_repo.obtener_por_id(id_contacto)
    if fila is None:
        raise ContactoNoEncontradoError(id_contacto)

    eliminado = contact_repo.eliminar_soft(id_contacto)
    return eliminado
