"""
logic/models.py — Definición de la entidad de dominio Contacto.

Este módulo no tiene dependencias de otras capas (DB ni CLI).
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Contacto:
    """
    Representa un contacto de la agenda.

    Parámetros:
        nombre    (str):           Nombre del contacto. Obligatorio.
        apellidos (str):           Apellidos del contacto.
        tel1      (Optional[str]): Teléfono principal. Obligatorio por validación.
        tel2      (Optional[str]): Teléfono secundario.
        email     (Optional[str]): Dirección de correo electrónico.
        notas     (Optional[str]): Texto libre de hasta 5 000 caracteres.
        id        (Optional[int]): Clave primaria asignada por la base de datos.

    Retorna:
        Contacto: Instancia inmutable de un contacto.
    """

    nombre: str
    apellidos: str = ""
    tel1: Optional[str] = None
    tel2: Optional[str] = None
    email: Optional[str] = None
    notas: Optional[str] = None
    id: Optional[int] = None

    @classmethod
    def desde_dict(cls, datos: dict) -> "Contacto":
        """
        Construye un Contacto a partir de un diccionario (p.ej. fila de MySQL).

        Parámetros:
            datos (dict): Diccionario con claves id, nombre, apellidos,
                          tel1, tel2, email, notas.

        Retorna:
            Contacto: Instancia del contacto.
        """
        return cls(
            id=datos.get("id"),
            nombre=datos.get("nombre", ""),
            apellidos=datos.get("apellidos", "") or "",
            tel1=datos.get("tel1"),
            tel2=datos.get("tel2"),
            email=datos.get("email"),
            notas=datos.get("notas"),
        )

    def a_dict(self) -> dict:
        """
        Convierte el contacto a diccionario para operaciones de persistencia.

        Retorna:
            dict: Representación del contacto sin el campo id.
        """
        return {
            "nombre": self.nombre,
            "apellidos": self.apellidos,
            "tel1": self.tel1,
            "tel2": self.tel2,
            "email": self.email,
            "notas": self.notas,
        }
