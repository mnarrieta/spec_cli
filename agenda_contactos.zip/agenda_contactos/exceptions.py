"""
exceptions.py — Jerarquía de excepciones personalizadas del proyecto.

Todas las excepciones de la aplicación heredan de AgendaError para
permitir capturas genéricas en el cli_agent sin perder contexto.
"""


class AgendaError(Exception):
    """Excepción base de la aplicación."""
    pass


class ValidationError(AgendaError):
    """
    Se lanza cuando un campo no supera las reglas de validación.

    Parámetros:
        codigo (str): Código de error estándar (ERR-001, ERR-002, ...).
        mensaje (str): Mensaje legible para el usuario.
    """
    def __init__(self, codigo: str, mensaje: str):
        self.codigo = codigo
        self.mensaje = mensaje
        super().__init__(f"[{codigo}] {mensaje}")


class ContactoDuplicadoError(AgendaError):
    """
    Se lanza cuando ya existe un contacto con el mismo teléfono o email.

    Parámetros:
        mensaje (str): Descripción del duplicado encontrado.
    """
    def __init__(self, mensaje: str = "Ya existe un contacto con ese teléfono o email."):
        self.codigo = "ERR-007"
        self.mensaje = mensaje
        super().__init__(f"[ERR-007] {mensaje}")


class ContactoNoEncontradoError(AgendaError):
    """
    Se lanza cuando no existe ningún contacto con el ID solicitado.

    Parámetros:
        id_contacto (int): ID que no se encontró.
    """
    def __init__(self, id_contacto: int = None):
        self.codigo = "ERR-005"
        self.mensaje = "No se encontró ningún contacto con ese ID."
        detalle = f" (id={id_contacto})" if id_contacto is not None else ""
        super().__init__(f"[ERR-005] {self.mensaje}{detalle}")


class ConexionBDError(AgendaError):
    """
    Se lanza cuando falla la conexión a la base de datos.

    Parámetros:
        causa (str): Descripción técnica del fallo.
    """
    def __init__(self, causa: str = ""):
        self.codigo = "ERR-006"
        self.mensaje = "Error de conexión a la base de datos."
        super().__init__(f"[ERR-006] {self.mensaje} {causa}".strip())
