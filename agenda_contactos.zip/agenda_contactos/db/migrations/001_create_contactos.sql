-- migrations/001_create_contactos.sql
-- Creación del esquema inicial de la agenda de contactos.
-- Fecha: 2026-05-04
-- Descripción: Tabla contactos con soft-delete e índices de búsqueda.

CREATE DATABASE IF NOT EXISTS agenda_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE agenda_db;

-- Usuario de la aplicación (solo DML, sin DDL ni GRANT)
-- Ejecutar como root:
-- CREATE USER 'agenda_user'@'localhost' IDENTIFIED BY 'tu_contraseña_segura';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON agenda_db.* TO 'agenda_user'@'localhost';
-- FLUSH PRIVILEGES;

CREATE TABLE IF NOT EXISTS contactos (
    id        INT          NOT NULL AUTO_INCREMENT,
    nombre    VARCHAR(100) NOT NULL,
    apellidos VARCHAR(200)          DEFAULT NULL,
    tel1      VARCHAR(20)  NOT NULL,
    tel2      VARCHAR(20)           DEFAULT NULL,
    email     VARCHAR(100)          DEFAULT NULL,
    notas     TEXT                  DEFAULT NULL,
    deleted_at DATETIME             DEFAULT NULL,

    PRIMARY KEY (id),
    INDEX idx_nombre    (nombre),
    INDEX idx_tel1      (tel1),
    INDEX idx_email     (email),
    INDEX idx_deleted_at (deleted_at)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
