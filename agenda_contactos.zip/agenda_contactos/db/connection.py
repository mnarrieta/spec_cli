"""
db/connection.py — Gestión de la conexión a MySQL (patrón Singleton).

Carga la configuración desde variables de entorno mediante python-dotenv.
Variables requeridas: DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD.
"""

import os
import mysql.connector
from mysql.connector import Error as MySQLError
from dotenv import load_dotenv

from exceptions import ConexionBDError

load_dotenv()


class Conexion:
    """
    Singleton que gestiona una única conexión a MySQL durante toda la ejecución.

    Uso:
        conn = Conexion.obtener()   # primera vez: crea la conexión
        conn = Conexion.obtener()   # siguientes: devuelve la misma instancia
        Conexion.cerrar()           # cierra y libera la conexión
    """

    _instancia = None

    @classmethod
    def obtener(cls) -> mysql.connector.MySQLConnection:
        """
        Devuelve la conexión activa. La crea si no existe o si está cerrada.

        Retorna:
            mysql.connector.MySQLConnection: Conexión activa a MySQL.

        Lanza:
            ConexionBDError: Si no se puede establecer la conexión.
        """
        if cls._instancia is None or not cls._instancia.is_connected():
            cls._instancia = cls._crear_conexion()
        return cls._instancia

    @classmethod
    def _crear_conexion(cls) -> mysql.connector.MySQLConnection:
        """
        Lee las variables de entorno y abre una nueva conexión.

        Retorna:
            mysql.connector.MySQLConnection: Nueva conexión autenticada.

        Lanza:
            ConexionBDError: Si las credenciales son incorrectas o el servidor
                             no está disponible.
        """
        try:
            conexion = mysql.connector.connect(
                host=os.getenv("DB_HOST", "localhost"),
                port=int(os.getenv("DB_PORT", 3306)),
                database=os.getenv("DB_NAME", "agenda_db"),
                user=os.getenv("DB_USER"),
                password=os.getenv("DB_PASSWORD"),
                charset="utf8mb4",
                collation="utf8mb4_unicode_ci",
                autocommit=True,
            )
            return conexion
        except MySQLError as e:
            raise ConexionBDError(str(e)) from e

    @classmethod
    def cerrar(cls):
        """
        Cierra la conexión activa y libera el Singleton.

        No lanza excepciones aunque la conexión ya estuviera cerrada.
        """
        if cls._instancia is not None and cls._instancia.is_connected():
            cls._instancia.close()
        cls._instancia = None
