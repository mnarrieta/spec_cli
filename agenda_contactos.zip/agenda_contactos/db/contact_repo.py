"""
db/contact_repo.py — Repositorio de acceso a datos para la entidad Contacto.

Todas las consultas usan parámetros (%s) para prevenir SQL Injection.
Las lecturas filtran siempre `deleted_at IS NULL` (soft-delete).
"""

from __future__ import annotations
from typing import Optional

from db.connection import Conexion
from exceptions import ConexionBDError

import mysql.connector


def _cursor():
    """Devuelve un cursor con dictionary=True desde la conexión Singleton."""
    try:
        return Conexion.obtener().cursor(dictionary=True)
    except Exception as e:
        raise ConexionBDError(str(e)) from e


def insertar(contacto: dict) -> int:
    """
    Inserta un nuevo contacto en la base de datos.

    Parámetros:
        contacto (dict): Diccionario con claves nombre, apellidos, tel1,
                         tel2, email, notas.

    Retorna:
        int: ID autogenerado del contacto insertado.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    sql = """
        INSERT INTO contactos (nombre, apellidos, tel1, tel2, email, notas)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    valores = (
        contacto.get("nombre"),
        contacto.get("apellidos"),
        contacto.get("tel1"),
        contacto.get("tel2"),
        contacto.get("email"),
        contacto.get("notas"),
    )
    try:
        cur = _cursor()
        cur.execute(sql, valores)
        return cur.lastrowid
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def obtener_por_id(id_contacto: int) -> Optional[dict]:
    """
    Recupera un contacto activo por su ID.

    Parámetros:
        id_contacto (int): Identificador del contacto.

    Retorna:
        dict | None: Fila del contacto o None si no existe (o está eliminado).

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    sql = """
        SELECT id, nombre, apellidos, tel1, tel2, email, notas
        FROM contactos
        WHERE id = %s AND deleted_at IS NULL
    """
    try:
        cur = _cursor()
        cur.execute(sql, (id_contacto,))
        return cur.fetchone()
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def listar(offset: int = 0, limit: int = 20) -> list[dict]:
    """
    Devuelve una página de contactos activos ordenados por nombre.

    Parámetros:
        offset (int): Número de filas a saltar (para paginación).
        limit  (int): Número máximo de filas a devolver.

    Retorna:
        list[dict]: Lista de contactos de la página solicitada.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    sql = """
        SELECT id, nombre, apellidos, tel1, tel2, email, notas
        FROM contactos
        WHERE deleted_at IS NULL
        ORDER BY nombre, apellidos
        LIMIT %s OFFSET %s
    """
    try:
        cur = _cursor()
        cur.execute(sql, (limit, offset))
        return cur.fetchall()
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def buscar(termino: str) -> list[dict]:
    """
    Busca contactos activos cuyo nombre, teléfono o email contengan el término.

    Parámetros:
        termino (str): Cadena de búsqueda (se aplica LIKE %termino%).

    Retorna:
        list[dict]: Lista de contactos que coinciden.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    patron = f"%{termino}%"
    sql = """
        SELECT id, nombre, apellidos, tel1, tel2, email, notas
        FROM contactos
        WHERE deleted_at IS NULL
          AND (nombre    LIKE %s
            OR apellidos LIKE %s
            OR tel1      LIKE %s
            OR tel2      LIKE %s
            OR email     LIKE %s)
        ORDER BY nombre, apellidos
    """
    try:
        cur = _cursor()
        cur.execute(sql, (patron, patron, patron, patron, patron))
        return cur.fetchall()
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def actualizar(id_contacto: int, campos: dict) -> bool:
    """
    Actualiza los campos indicados de un contacto existente.

    Parámetros:
        id_contacto (int): ID del contacto a modificar.
        campos (dict): Diccionario con los campos a actualizar y sus nuevos valores.

    Retorna:
        bool: True si se actualizó al menos una fila, False si no se encontró.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    if not campos:
        return False

    columnas_permitidas = {"nombre", "apellidos", "tel1", "tel2", "email", "notas"}
    campos_filtrados = {k: v for k, v in campos.items() if k in columnas_permitidas}

    if not campos_filtrados:
        return False

    set_clause = ", ".join(f"{col} = %s" for col in campos_filtrados)
    sql = f"UPDATE contactos SET {set_clause} WHERE id = %s AND deleted_at IS NULL"
    valores = list(campos_filtrados.values()) + [id_contacto]

    try:
        cur = _cursor()
        cur.execute(sql, valores)
        return cur.rowcount > 0
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def eliminar_soft(id_contacto: int) -> bool:
    """
    Realiza un soft-delete del contacto marcando deleted_at con la fecha actual.

    Parámetros:
        id_contacto (int): ID del contacto a eliminar.

    Retorna:
        bool: True si se marcó al menos una fila, False si no se encontró.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    sql = """
        UPDATE contactos
        SET deleted_at = NOW()
        WHERE id = %s AND deleted_at IS NULL
    """
    try:
        cur = _cursor()
        cur.execute(sql, (id_contacto,))
        return cur.rowcount > 0
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def contar_total() -> int:
    """
    Devuelve el número total de contactos activos (sin deleted_at).

    Retorna:
        int: Recuento de contactos activos.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    sql = "SELECT COUNT(*) AS total FROM contactos WHERE deleted_at IS NULL"
    try:
        cur = _cursor()
        cur.execute(sql)
        fila = cur.fetchone()
        return fila["total"] if fila else 0
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e


def existe_duplicado(tel1: str = None, email: str = None,
                     excluir_id: int = None) -> bool:
    """
    Comprueba si ya existe un contacto activo con el mismo tel1 o email.

    Parámetros:
        tel1       (str): Teléfono principal a comprobar (opcional).
        email      (str): Email a comprobar (opcional).
        excluir_id (int): ID a excluir de la búsqueda (útil en edición).

    Retorna:
        bool: True si existe al menos un duplicado.

    Lanza:
        ConexionBDError: Si falla la operación en base de datos.
    """
    condiciones = []
    valores = []

    if tel1:
        condiciones.append("tel1 = %s")
        valores.append(tel1)
    if email:
        condiciones.append("email = %s")
        valores.append(email)

    if not condiciones:
        return False

    where_or = " OR ".join(condiciones)
    sql = f"""
        SELECT COUNT(*) AS total
        FROM contactos
        WHERE deleted_at IS NULL AND ({where_or})
    """

    if excluir_id is not None:
        sql += " AND id != %s"
        valores.append(excluir_id)

    try:
        cur = _cursor()
        cur.execute(sql, valores)
        fila = cur.fetchone()
        return (fila["total"] if fila else 0) > 0
    except mysql.connector.Error as e:
        raise ConexionBDError(str(e)) from e
