"""
tests/test_validators.py — Tests unitarios para logic/validators.py.

Cubre los casos válidos e inválidos de cada función de validación
para alcanzar la cobertura mínima del 80 % exigida en constitution.md.
"""

import sys
import os

# Aseguramos que el directorio raíz del proyecto esté en el path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from logic.validators import (
    validar_nombre,
    validar_apellidos,
    validar_telefono,
    validar_email,
    validar_notas,
    validar_contacto,
)
from exceptions import ValidationError


# ── validar_nombre ────────────────────────────────────────────────────────────

class TestValidarNombre:
    def test_nombre_valido(self):
        assert validar_nombre("Ana") is True

    def test_nombre_con_tilde(self):
        assert validar_nombre("José María") is True

    def test_nombre_con_guion(self):
        assert validar_nombre("Ana-Belén") is True

    def test_nombre_vacio_lanza_error(self):
        with pytest.raises(ValidationError) as exc:
            validar_nombre("")
        assert exc.value.codigo == "ERR-001"

    def test_nombre_none_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_nombre(None)

    def test_nombre_un_caracter_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_nombre("A")

    def test_nombre_demasiado_largo_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_nombre("A" * 101)

    def test_nombre_con_numeros_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_nombre("Ana123")

    def test_nombre_con_caracteres_especiales_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_nombre("Ana@García")


# ── validar_apellidos ─────────────────────────────────────────────────────────

class TestValidarApellidos:
    def test_apellidos_validos(self):
        assert validar_apellidos("García López") is True

    def test_apellidos_vacios_son_validos(self):
        assert validar_apellidos("") is True

    def test_apellidos_none_son_validos(self):
        assert validar_apellidos(None) is True

    def test_apellidos_demasiado_cortos_lanzan_error(self):
        with pytest.raises(ValidationError):
            validar_apellidos("G")

    def test_apellidos_demasiado_largos_lanzan_error(self):
        with pytest.raises(ValidationError):
            validar_apellidos("G" * 201)


# ── validar_telefono ──────────────────────────────────────────────────────────

class TestValidarTelefono:
    def test_telefono_nacional(self):
        assert validar_telefono("612345678") is True

    def test_telefono_internacional(self):
        assert validar_telefono("+34 612 345 678") is True

    def test_telefono_con_parentesis(self):
        assert validar_telefono("(+34) 612-345-678") is True

    def test_telefono_vacio_es_valido(self):
        assert validar_telefono("") is True

    def test_telefono_none_es_valido(self):
        assert validar_telefono(None) is True

    def test_telefono_demasiado_corto_lanza_error(self):
        with pytest.raises(ValidationError) as exc:
            validar_telefono("123")
        assert exc.value.codigo == "ERR-004"

    def test_telefono_con_letras_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_telefono("612abc678")

    def test_telefono_demasiado_largo_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_telefono("1" * 21)


# ── validar_email ─────────────────────────────────────────────────────────────

class TestValidarEmail:
    def test_email_valido(self):
        assert validar_email("usuario@ejemplo.com") is True

    def test_email_con_subdominio(self):
        assert validar_email("user@mail.empresa.es") is True

    def test_email_vacio_es_valido(self):
        assert validar_email("") is True

    def test_email_none_es_valido(self):
        assert validar_email(None) is True

    def test_email_sin_arroba_lanza_error(self):
        with pytest.raises(ValidationError) as exc:
            validar_email("usuarioejemplo.com")
        assert exc.value.codigo == "ERR-003"

    def test_email_sin_dominio_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_email("usuario@")

    def test_email_sin_tld_lanza_error(self):
        with pytest.raises(ValidationError):
            validar_email("usuario@dominio")


# ── validar_notas ─────────────────────────────────────────────────────────────

class TestValidarNotas:
    def test_notas_vacias_son_validas(self):
        assert validar_notas("") is True

    def test_notas_normales_son_validas(self):
        assert validar_notas("Conocido en la conferencia de 2025.") is True

    def test_notas_en_limite_son_validas(self):
        assert validar_notas("A" * 5000) is True

    def test_notas_demasiado_largas_lanzan_error(self):
        with pytest.raises(ValidationError):
            validar_notas("A" * 5001)


# ── validar_contacto ──────────────────────────────────────────────────────────

class TestValidarContacto:
    def test_contacto_completo_valido(self):
        datos = {
            "nombre": "María",
            "apellidos": "González",
            "tel1": "612345678",
            "tel2": "",
            "email": "maria@ejemplo.com",
            "notas": "",
        }
        assert validar_contacto(datos) is True

    def test_contacto_sin_nombre_lanza_error(self):
        datos = {"nombre": "", "tel1": "612345678"}
        with pytest.raises(ValidationError) as exc:
            validar_contacto(datos)
        assert exc.value.codigo == "ERR-001"

    def test_contacto_sin_tel1_lanza_error(self):
        datos = {"nombre": "Ana", "tel1": ""}
        with pytest.raises(ValidationError) as exc:
            validar_contacto(datos)
        assert exc.value.codigo == "ERR-002"

    def test_contacto_minimo_valido(self):
        datos = {"nombre": "Pedro", "tel1": "912345678"}
        assert validar_contacto(datos) is True
