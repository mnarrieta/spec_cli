"""
cli/formatters.py — Funciones de presentación puras para la CLI.

No contienen lógica de negocio. Solo formateo de salida con tabulate.
"""

from __future__ import annotations
from tabulate import tabulate

from logic.models import Contacto


# ── Colores ANSI (compatibles con terminales estándar) ──────────────────────

_VERDE  = "\033[92m"
_ROJO   = "\033[91m"
_AMARILLO = "\033[93m"
_AZUL   = "\033[94m"
_RESET  = "\033[0m"
_NEGRITA = "\033[1m"


def tabla_contactos(contactos: list[Contacto]) -> str:
    """
    Renderiza una lista de contactos en formato tabla con tabulate.

    Parámetros:
        contactos (list[Contacto]): Lista de contactos a mostrar.

    Retorna:
        str: Tabla formateada lista para imprimir.
    """
    if not contactos:
        return f"{_AMARILLO}No hay contactos para mostrar.{_RESET}"

    filas = [
        [
            c.id,
            c.nombre,
            c.apellidos or "—",
            c.tel1 or "—",
            c.tel2 or "—",
            c.email or "—",
        ]
        for c in contactos
    ]
    cabeceras = ["ID", "Nombre", "Apellidos", "Teléfono 1", "Teléfono 2", "Email"]
    return tabulate(filas, headers=cabeceras, tablefmt="simple")


def detalle_contacto(contacto: Contacto) -> str:
    """
    Muestra todos los campos de un contacto en formato vertical legible.

    Parámetros:
        contacto (Contacto): El contacto a mostrar.

    Retorna:
        str: Texto formateado con todos los campos.
    """
    lineas = [
        f"{_NEGRITA}{'─' * 40}{_RESET}",
        f"  {_AZUL}ID:{_RESET}          {contacto.id}",
        f"  {_AZUL}Nombre:{_RESET}      {contacto.nombre}",
        f"  {_AZUL}Apellidos:{_RESET}   {contacto.apellidos or '—'}",
        f"  {_AZUL}Teléfono 1:{_RESET}  {contacto.tel1 or '—'}",
        f"  {_AZUL}Teléfono 2:{_RESET}  {contacto.tel2 or '—'}",
        f"  {_AZUL}Email:{_RESET}       {contacto.email or '—'}",
        f"  {_AZUL}Notas:{_RESET}       {contacto.notas or '—'}",
        f"{_NEGRITA}{'─' * 40}{_RESET}",
    ]
    return "\n".join(lineas)


def mensaje_error(codigo: str, msg: str) -> str:
    """
    Formatea un mensaje de error con código y descripción.

    Parámetros:
        codigo (str): Código de error (p.ej. ERR-001).
        msg    (str): Descripción legible del error.

    Retorna:
        str: Mensaje de error formateado.
    """
    return f"{_ROJO}✗ [{codigo}] {msg}{_RESET}"


def mensaje_exito(msg: str) -> str:
    """
    Formatea un mensaje de confirmación de operación exitosa.

    Parámetros:
        msg (str): Texto del mensaje.

    Retorna:
        str: Mensaje de éxito formateado.
    """
    return f"{_VERDE}✓ {msg}{_RESET}"


def mensaje_aviso(msg: str) -> str:
    """
    Formatea un mensaje de aviso o advertencia.

    Parámetros:
        msg (str): Texto del aviso.

    Retorna:
        str: Mensaje de aviso formateado.
    """
    return f"{_AMARILLO}⚠ {msg}{_RESET}"


def cabecera(titulo: str) -> str:
    """
    Formatea un título de sección en negrita con separador.

    Parámetros:
        titulo (str): Texto del título.

    Retorna:
        str: Cabecera formateada.
    """
    separador = "═" * (len(titulo) + 4)
    return f"\n{_NEGRITA}{_AZUL}{separador}\n  {titulo}\n{separador}{_RESET}\n"
