"""
cli/menu.py — Control de flujo de la interfaz de usuario en línea de comandos.

Contiene el bucle principal y todos los submenús de la agenda.
No accede directamente a la base de datos; delega siempre en logic/services.py.
"""

from __future__ import annotations
import math

from cli import formatters as fmt
from logic import services
from exceptions import (
    AgendaError,
    ContactoDuplicadoError,
    ContactoNoEncontradoError,
    ValidationError,
)


# ── Utilidades internas ──────────────────────────────────────────────────────

def _leer(prompt: str, opcional: bool = False) -> str:
    """
    Lee una línea de la entrada estándar con prompt.

    Parámetros:
        prompt   (str):  Texto a mostrar antes del cursor.
        opcional (bool): Si True, el valor vacío es aceptable.

    Retorna:
        str: Valor introducido (con strip aplicado).
    """
    while True:
        valor = input(f"  {prompt}: ").strip()
        if valor or opcional:
            return valor
        print(fmt.mensaje_error("ERR-001", "Este campo es obligatorio."))


def _confirmar(pregunta: str) -> bool:
    """
    Solicita una confirmación s/N al usuario.

    Parámetros:
        pregunta (str): Texto de la pregunta.

    Retorna:
        bool: True si el usuario responde 's' o 'S'.
    """
    respuesta = input(f"  {pregunta} [s/N]: ").strip().lower()
    return respuesta == "s"


def _pausar():
    """Pausa la ejecución hasta que el usuario pulsa Enter."""
    input("\n  Pulsa Enter para continuar...")


# ── Submenús ─────────────────────────────────────────────────────────────────

def menu_anadir():
    """Submenú de creación de un nuevo contacto. (CU-01)"""
    print(fmt.cabecera("AÑADIR CONTACTO"))

    datos = {
        "nombre":    _leer("Nombre (*obligatorio*)"),
        "apellidos": _leer("Apellidos", opcional=True),
        "tel1":      _leer("Teléfono principal (*obligatorio*)"),
        "tel2":      _leer("Teléfono secundario", opcional=True),
        "email":     _leer("Email", opcional=True),
        "notas":     _leer("Notas", opcional=True),
    }

    try:
        contacto = services.crear_contacto(datos)
        print(fmt.mensaje_exito(f"Contacto guardado con ID {contacto.id}."))
        print(fmt.detalle_contacto(contacto))

    except ContactoDuplicadoError as e:
        print(fmt.mensaje_aviso(e.mensaje))
        if _confirmar("¿Deseas guardarlo igualmente?"):
            try:
                contacto = services.crear_contacto(datos, forzar=True)
                print(fmt.mensaje_exito(f"Contacto guardado con ID {contacto.id}."))
                print(fmt.detalle_contacto(contacto))
            except AgendaError as e2:
                print(fmt.mensaje_error(getattr(e2, "codigo", "ERR"), str(e2)))

    except ValidationError as e:
        print(fmt.mensaje_error(e.codigo, e.mensaje))

    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))

    _pausar()


def menu_listar():
    """Muestra todos los contactos activos con paginación de 20 en 20. (CU-05)"""
    pagina = 1
    tam = 20

    while True:
        print(fmt.cabecera(f"LISTADO DE CONTACTOS — Página {pagina}"))
        try:
            contactos, total = services.listar_contactos(pagina=pagina, tam=tam)
        except AgendaError as e:
            print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))
            _pausar()
            return

        if not contactos and pagina == 1:
            print(fmt.mensaje_aviso("La agenda está vacía."))
            _pausar()
            return

        print(fmt.tabla_contactos(contactos))
        total_paginas = max(1, math.ceil(total / tam))
        print(f"\n  Total: {total} contacto(s)  |  Página {pagina}/{total_paginas}")

        opciones = []
        if pagina > 1:
            opciones.append("(A) Anterior")
        if pagina < total_paginas:
            opciones.append("(S) Siguiente")
        opciones.append("(0) Volver")

        print("  " + "  |  ".join(opciones))
        opcion = input("  Opción: ").strip().lower()

        if opcion == "s" and pagina < total_paginas:
            pagina += 1
        elif opcion == "a" and pagina > 1:
            pagina -= 1
        elif opcion == "0":
            return


def menu_buscar():
    """Solicita un término y muestra los contactos coincidentes."""
    print(fmt.cabecera("BUSCAR CONTACTO"))
    termino = _leer("Introduce nombre, teléfono o email a buscar")

    try:
        contactos = services.buscar_contactos(termino)
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))
        _pausar()
        return

    if not contactos:
        print(fmt.mensaje_aviso(f"No se encontraron contactos para '{termino}'."))
    else:
        print(f"\n  Resultados para '{termino}':\n")
        print(fmt.tabla_contactos(contactos))

    _pausar()


def menu_ver():
    """Muestra el detalle completo de un contacto por ID. (CU-02)"""
    print(fmt.cabecera("VER CONTACTO"))
    try:
        id_str = _leer("ID del contacto")
        id_contacto = int(id_str)
        contacto = services.obtener_contacto(id_contacto)
        print(fmt.detalle_contacto(contacto))
    except ValueError:
        print(fmt.mensaje_error("ERR-001", "El ID debe ser un número entero."))
    except ContactoNoEncontradoError as e:
        print(fmt.mensaje_error(e.codigo, e.mensaje))
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))

    _pausar()


def menu_editar():
    """Edición campo a campo de un contacto. (CU-04)"""
    print(fmt.cabecera("EDITAR CONTACTO"))
    try:
        id_str = _leer("ID del contacto a editar")
        id_contacto = int(id_str)
        contacto = services.obtener_contacto(id_contacto)
    except ValueError:
        print(fmt.mensaje_error("ERR-001", "El ID debe ser un número entero."))
        _pausar()
        return
    except ContactoNoEncontradoError as e:
        print(fmt.mensaje_error(e.codigo, e.mensaje))
        _pausar()
        return
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))
        _pausar()
        return

    print(fmt.detalle_contacto(contacto))
    print("\n  Deja el campo vacío para mantener el valor actual.\n")

    campos = ["nombre", "apellidos", "tel1", "tel2", "email", "notas"]
    etiquetas = {
        "nombre": "Nombre",
        "apellidos": "Apellidos",
        "tel1": "Teléfono 1",
        "tel2": "Teléfono 2",
        "email": "Email",
        "notas": "Notas",
    }
    valores_actuales = contacto.a_dict()
    cambios = {}

    for campo in campos:
        actual = valores_actuales.get(campo) or ""
        nuevo = input(f"  {etiquetas[campo]} [{actual}]: ").strip()
        if nuevo:
            cambios[campo] = nuevo

    if not cambios:
        print(fmt.mensaje_aviso("No se realizaron cambios."))
        _pausar()
        return

    try:
        contacto_actualizado = services.actualizar_contacto(id_contacto, cambios)
        print(fmt.mensaje_exito("Contacto actualizado correctamente."))
        print(fmt.detalle_contacto(contacto_actualizado))
    except ValidationError as e:
        print(fmt.mensaje_error(e.codigo, e.mensaje))
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))

    _pausar()


def menu_eliminar():
    """Solicita confirmación y realiza soft-delete del contacto. (CU-03)"""
    print(fmt.cabecera("ELIMINAR CONTACTO"))
    try:
        id_str = _leer("ID del contacto a eliminar")
        id_contacto = int(id_str)
        contacto = services.obtener_contacto(id_contacto)
    except ValueError:
        print(fmt.mensaje_error("ERR-001", "El ID debe ser un número entero."))
        _pausar()
        return
    except ContactoNoEncontradoError as e:
        print(fmt.mensaje_error(e.codigo, e.mensaje))
        _pausar()
        return
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))
        _pausar()
        return

    print(fmt.detalle_contacto(contacto))

    if not _confirmar("¿Seguro que deseas eliminar este contacto?"):
        print(fmt.mensaje_aviso("Operación cancelada."))
        _pausar()
        return

    try:
        services.eliminar_contacto(id_contacto)
        print(fmt.mensaje_exito(f"Contacto {id_contacto} eliminado correctamente."))
    except AgendaError as e:
        print(fmt.mensaje_error(getattr(e, "codigo", "ERR"), str(e)))

    _pausar()


# ── Bucle principal ──────────────────────────────────────────────────────────

_OPCIONES_MENU = {
    "1": ("Añadir contacto",   menu_anadir),
    "2": ("Listar contactos",  menu_listar),
    "3": ("Buscar contacto",   menu_buscar),
    "4": ("Ver contacto",      menu_ver),
    "5": ("Editar contacto",   menu_editar),
    "6": ("Eliminar contacto", menu_eliminar),
    "0": ("Salir",             None),
}


def run():
    """
    Bucle principal del menú. Muestra las opciones y despacha la acción elegida.

    Retorna:
        None: Sale cuando el usuario elige la opción 0.
    """
    while True:
        print(fmt.cabecera("AGENDA DE CONTACTOS"))
        for clave, (etiqueta, _) in _OPCIONES_MENU.items():
            print(f"  [{clave}] {etiqueta}")

        opcion = input("\n  Elige una opción: ").strip()

        if opcion not in _OPCIONES_MENU:
            print(fmt.mensaje_error("ERR-001", "Opción no válida. Elige entre 0 y 6."))
            _pausar()
            continue

        etiqueta, accion = _OPCIONES_MENU[opcion]

        if accion is None:
            print(fmt.mensaje_exito("¡Hasta pronto!"))
            break

        accion()
